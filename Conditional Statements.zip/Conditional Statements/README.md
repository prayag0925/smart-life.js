# Smart Life Assistant

This project contains four small JavaScript-based systems for practicing basic programming logic, conditional statements, and user interaction via `prompt` and `alert`.

---

## 📝 Project Description

The program consists of four main modules:

1. **Fitness Suggestion System** – Checks if your weight is in the ideal range based on your age.
2. **Monthly Budget Planner** – Suggests spending or saving strategies based on your income.
3. **Mobile Data Usage Alert System** – Tells you if you’re a low, normal, or heavy data user.
4. **Change Password System** – Helps securely update your password.

---

## 🛠 Features & Logic

### 1️⃣ Fitness Suggestion System
- **Input:** Age (years), Weight (kg)
- **Logic:**
  - Age groups have defined minimum and maximum healthy weights.
  - Below minimum → Underweight
  - Above maximum → Overweight
  - Between → Fit

---

### 2️⃣ Monthly Budget Planner
- **Input:** Monthly income
- **Logic:**
  - `< ₹10,000` → Spend cautiously and save more.
  - `₹10,000 – ₹29,999` → Balanced budget.
  - `≥ ₹30,000` → Consider investing.

---

### 3️⃣ Mobile Data Usage Alert System
- **Input:** Data used in GB per month
- **Logic:**
  - `< 5GB` → Low usage
  - `5GB – 15GB` → Normal usage
  - `> 15GB` → Heavy usage (Upgrade plan)

---

### 4️⃣ Change Password System
- **Input:** Old password, new password, confirm password
- **Logic:**
  - New password ≠ old password
  - New password must match confirm password
  - If valid → Password updated successfully

---

## 📸 Output Screenshots 

**1. Fitness Suggestion System**

![Fitness Output](screenshorts/fitness.png)

**2. Monthly Budget Planner**

![Fitness Output](screenshorts/monthly_budget.png)

**3. Mobile Data Usage Alert System**

![Fitness Output](screenshorts/mobile_data.png)

**4. Change Password**

![Fitness Output](screenshorts/change_password.png)

---

## 🚀 How to Run
1. Clone or download this repository.
2. Open `smartLifeAssistant.js` in any browser console or code editor.
3. Run the script.
4. Provide inputs as prompted.
5. View the results in the browser console.


